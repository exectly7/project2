﻿namespace project2
{
    internal static class Program
    {
        public static void Main()
        {
            Menu menu = new();
            
            menu.RunMenu();
        }
    }
}